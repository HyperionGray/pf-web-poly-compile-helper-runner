![PODMAN logo](https://raw.githubusercontent.com/containers/common/main/logos/podman-logo-full-vert.png)

# New home

The contents of the hello image have been moved to a dedicated repository:
https://github.com/containers/PodmanHello

# Warning

**DO NOT DELETE THIS DIRECTORY! Legacy tests depend on it.**
