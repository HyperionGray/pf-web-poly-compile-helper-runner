//###
//  ASCII art by the incomparable Máirín Duffy,
//  duffy@redhat.com, Twitter: @mairin
//  January 2022
//###

#include <stdio.h>
int main() {
    puts("\
!... Hello Podman World ...!\n\
\n\
         .--\"--.           \n\
       / -     - \\         \n\
      / (O)   (O) \\        \n\
   ~~~| -=(,Y,)=- |         \n\
    .---. /`  \\   |~~      \n\
 ~/  o  o \\~~~~.----. ~~   \n\
  | =(X)= |~  / (O (O) \\   \n\
   ~~~~~~~  ~| =(Y_)=-  |   \n\
  ~~~~    ~~~|   U      |~~ \n\
\n\
Project:   https://github.com/containers/podman\n\
Website:   https://podman.io\n\
Documents: https://docs.podman.io\n\
Twitter:   @Podman_io");
}
