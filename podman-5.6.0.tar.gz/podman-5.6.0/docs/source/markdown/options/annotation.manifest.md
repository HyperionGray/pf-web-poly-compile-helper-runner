####> This option file is used in:
####>   podman artifact add, manifest add, manifest annotate
####> If file is edited, make sure the changes
####> are applicable to all of those.
#### **--annotation**=*annotation=value*

Set an annotation on the entry for the specified image or artifact.
