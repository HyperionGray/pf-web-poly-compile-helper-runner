####> This option file is used in:
####>   podman create, kube play, run
####> If file is edited, make sure the changes
####> are applicable to all of those.
#### **--annotation**=*key=value*

Add an annotation to the container<<| or pod>>. This option can be set multiple times.
