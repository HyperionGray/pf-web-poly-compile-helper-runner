####> This option file is used in:
####>   podman build, farm build
####> If file is edited, make sure the changes
####> are applicable to all of those.
#### **--inherit-labels**

Inherit the labels from the base image or base stages. (default true).
