####> This option file is used in:
####>   podman create, run, update
####> If file is edited, make sure the changes
####> are applicable to all of those.
#### **--health-max-log-size**=*size of stored logs*

Set maximum length in characters of stored HealthCheck log. ("0" value means an infinite log length) (Default: 500 characters)
