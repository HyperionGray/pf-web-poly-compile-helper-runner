####> This option file is used in:
####>   podman build, create, pull, push, run
####> If file is edited, make sure the changes
####> are applicable to all of those.
#### **--disable-content-trust**

This is a Docker-specific option to disable image verification to a container
registry and is not supported by Podman. This option is a NOOP and provided
solely for scripting compatibility.
