####> This option file is used in:
####>   podman logs, pod logs
####> If file is edited, make sure the changes
####> are applicable to all of those.
#### **--color**

Output the containers with different colors in the log.
