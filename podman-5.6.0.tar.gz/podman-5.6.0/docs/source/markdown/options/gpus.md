####> This option file is used in:
####>   podman create, pod clone, pod create, run
####> If file is edited, make sure the changes
####> are applicable to all of those.
#### **--gpus**=*ENTRY*

GPU devices to add to the container ('all' to pass all GPUs) Currently only
Nvidia devices are supported.
