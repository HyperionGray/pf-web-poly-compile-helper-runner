####> This option file is used in:
####>   podman container clone, create, pod clone, pod create, run, update
####> If file is edited, make sure the changes
####> are applicable to all of those.
#### **--blkio-weight-device**=*device:weight*

Block IO relative device weight.
